
<!-- About Main Area Start -->
 <div class="about-main-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-7 col-md-12">
						<div class="about-img">
							<img class="img" src="../img/banner/about.jpg" alt="about-us">
						</div>
					</div>
					<div class="col-lg-5 col-md-12">
						<div class="about-content">
							<h3>Почему мы?</h3>
							<p>Мы работаем напрямую с Турецкой фабрикой. Весь товар наивысшего качества от производителя.</p>
							<ul class="mt-20 about-content-list">
								<li><a href="#">Работаем по честной цене</a></li>
								<li><a href="#">Акции и подарки</a></li>
								<li><a href="#">Доставка транспортными компаниями по РФ</a></li>
								<li><a href="#">Собственная доставка по городу от 100 руб.</a></li>
								<li><a href="#">Гарантия</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
       <!-- About Main Area End -->
        <!-- Our Mission Start -->
        <div class="about-bottom pt-50 pb-60">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="ht-single-about pb-sm-40">
                            <h3>Наш опыт</h3>
                            <p>Уже больше года наш интернет-мгазин реализует Фатин на территории РФ.</p>
                            <p>Мы стараемся держать цены на весь ассортимент наших товаров, гибкая система скидок позволяет нам радовать наших покупателей.</p>
                            <p>У нас своя логистика, что позволяет доставлять товары по городу в кротчайшие сроки. Отправка по РФ любой удобной ТК.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="ht-single-about">
                            <h3>Наша Мотивация</h3>
                            <div class="ht-about-work">
                                <span>1</span>
                                <div class="ht-work-text">
                                    <h5><a href="#">Счастливые покупатели!</a></h5>
                                    <p>Удовлетворить спрос покупателя - наша задача.</p>
                                </div>
                            </div>
                            <div class="ht-about-work">
                                <span>2</span>
                                <div class="ht-work-text">
                                    <h5><a href="#">Акции и Бонусы</a></h5>
                                    <p>Иногда мы проводим розыгрыш товаров среди наших покупателей.</p>
                                </div>
                            </div>
                            <div class="ht-about-work">
                                <span>3</span>
                                <div class="ht-work-text">
                                    <h5><a href="#">Благотворительность</a></h5>
                                    <p>Помогаем некоммерческим организациям.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Our Mission End -->
        <!-- Brand Logo Start -->
        <div class="brand-area pb-60">
            <div class="container">
                          
            </div>
        </div>
        <!-- Brand Logo End -->

